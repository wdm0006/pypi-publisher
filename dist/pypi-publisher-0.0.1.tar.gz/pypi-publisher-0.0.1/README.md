pypi-publisher (ppp)
====================

version number: 0.0.1
author: Will McGinnis

Overview
--------

A cli for publishing packages to pypi, without the hassle.

Installation / Usage
--------------------

To install use pip (soon, not yet):

    $ pip install ppp


Or clone the repo:

    $ git clone https://github.com/wdm0006/ppp.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD